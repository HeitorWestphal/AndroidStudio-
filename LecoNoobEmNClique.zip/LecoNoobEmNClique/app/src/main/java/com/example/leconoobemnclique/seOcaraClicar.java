package com.example.leconoobemnclique;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

public class seOcaraClicar extends AppCompatActivity {

    private MediaPlayer mediaPlayer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_se_ocara_clicar);

        mediaPlayer = MediaPlayer.create(this, R.raw.sol);
        mediaPlayer.start();


        new Thread(new Runnable() {
            int count = 1;
            @Override
            public void run() {
                while (true) {
                    try{
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "\"\" O SOL\"\"\n" +
                                    "OLHÁ O SOL, TÁ MUITO QUENTE HEIN\n" +
                                    "OLHÁ O SOL, TÁ MUITO QUENTE HEIN\n" +
                                    "O CÉU ESTÁ TÃO LINDO AZUL\n" +
                                    "E O SOL ESTÁ MUITO QUENTE\n" +
                                    "ENTÃO TE PEÇO POR FAVOR\n" +
                                    "PROTEJA A SUA PELE, PASSE O PROTETOR\n" +
                                    "O CÉU ESTÁ TÃO LINDO AZUL\n" +
                                    "E O SOL ESTÁ MUITO QUENTE\n" +
                                    "ENTÃO TE PEÇO POR FAVOR\n" +
                                    "PROTEJA A SUA PELE, PASSE O PROTETOR\n" +
                                    "DANÇA BALANÇA PASSE O PROTETOR\n" +
                                    "TA QUENTE TA CALOR, TA QUENTE TA CALOR\n" +
                                    "DANÇA BALANÇA PASSE O PROTETOR\n" +
                                    "CUIDADO PRA NÃO SE QUEIMAR\n" +
                                    "DANÇA BALANÇA PASSE O PROTETOR\n" +
                                    "TA QUENTE TA CALOR, TA QUENTE TA CALOR\n" +
                                    "DANÇA BALANÇA PASSE O PROTETOR\n" +
                                    "PASSE O PROTETOR SOLAR.\n" +
                                    "OLHÁ O SOL, TÁ MUITO QUENTE HEIN\n" +
                                    "OLHÁ O SOL, TÁ MUITO QUENTE HEIN", Toast.LENGTH_SHORT).show();
                            count++;
                        }
                    });
                }


            }
        }).start();

    }
    protected void onPause(){
        super.onPause();
        mediaPlayer.pause();
    }
    protected void onResume() {
        super.onResume();
        mediaPlayer.start();
    }
    protected void onDestroy() {
        super.onDestroy();
        mediaPlayer.release();
    }
}